//
//  AIChatTests.swift
//  AIChatTests
//
//  Created by Morse on 1/9/25.
//

import Testing

struct AIChatTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
