//
//  AlertType.swift
//  AIChat
//
//  Created by Morse on 2/7/25.
//


