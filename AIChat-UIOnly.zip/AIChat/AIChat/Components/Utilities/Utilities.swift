//
//  Utilities.swift
//  AIChat
//
//  Created by Morse on 1/30/25.
//

import SwiftfulUtilities

typealias Utilities = SwiftfulUtilities.Utilities
