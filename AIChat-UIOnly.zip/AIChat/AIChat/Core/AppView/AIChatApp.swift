//
//  AIChatApp.swift
//  AIChat
//
//  Created by Morse on 1/9/25.
//

import SwiftUI

@main
struct AIChatApp: App {
    var body: some Scene {
        WindowGroup {
            AppView()
        }
    }
}
